<?php
    $host = "localhost";
    $user = "vvv0032";
    $pass = "Hhd3712493!";
    $db = "vvv0032";

    $connect = new mysqli($host, $user, $pass, $db);    
    $connect -> set_charset("utf8");
?>
