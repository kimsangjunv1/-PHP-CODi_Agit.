<footer id="footer">
    <h2 class="blind">푸터 영역입니다.</h2>
    <div class="footer__inner container">
        <address>Copyright @2022 CODi</address>
        <div><a href="index.html">blog by CODi</a></div>
    </div>
</footer>