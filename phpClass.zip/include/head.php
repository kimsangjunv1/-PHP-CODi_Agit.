<!-- CSS -->
<link rel="stylesheet" href="../assets/css/style.css">
<!-- META -->
<meta name="author" content="webstoryboy">
<meta name="description" content="PHP 사이트 만들기입니다.">
<meta name="keyword" content="사이트, 만들기, 튜토리얼, 웹스토리보이">
<meta name="robots" content="all">
<!-- ICON -->
<link rel="icon" href="../assets/img/icon_256.png" />
<link rel="shortcut icon" href="../assets/img/icon_256.png" />
<link rel="icon" type="image/png" sizes="256x256" href="../assets/img/icon_256.png" />
<link rel="icon" type="image/png" sizes="192x192" href="../assets/img/icon_192.png" />
<link rel="icon" type="image/png" sizes="32x32" href="../assets/img/icon_32.png" />
<link rel="icon" type="image/png" sizes="16x16" href="../assets/img/icon_16.png" />