<ul>
    <li><a href="blogCategory.php?category=html"><span></span><em>html</em></a></li>
    <li><a href="blogCategory.php?category=jquery"><span></span><em>jquery</em></a></li>
    <li><a href="blogCategory.php?category=javascript"><span></span><em>javascript</em></a></li>
    <li><a href="blogCategory.php?category=css"><span></span><em>css</em></a></li>
</ul>
